package com.example.emailapplication;

import android.app.Activity;

public class RigisterActivity extends Activity {
}
