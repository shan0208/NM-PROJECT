# Adaptive-Mail-Flexible-Email-Client-App

Google Developers Link - https://g.dev/mr_sundar
Video Demonstration Link - https://drive.google.com/file/d/1zhqoIttJRLGcl5r25rnmkH7WFKeP7GoJ/view?usp=sharing
